const express = require("express");
const router = express.Router();
const controller = require("../../controllers/client/flight.controller");
const  { validateInput } = require("../../middlewares/validate.middleware");
const { searchFlightSchema } = require("../../schemas/flight.schema");
const { fullsearchQuerySchema } = require("../../schemas/flight.schema");
const { parseFullsearchParams } = require("../../middlewares/parseFullsearch.middleware");

router.get(
  "/sync",
  validateInput(searchFlightSchema, "query"),
  controller.searchAndStoreFlights
); // /api/v1/flights/sync?from=SGN&to=HAN&date=2024-06-02

router.get(
  "/fullsearch",
  validateInput(fullsearchQuerySchema, "query"),
  parseFullsearchParams,
  controller.fullSearchHandler
);

module.exports = router;