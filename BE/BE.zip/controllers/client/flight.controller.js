const amadeus = require("../../config/amadeus");
const Flight = require("../../models/flight.model");

exports.searchAndStoreFlights = async (req, res) => {
  const { from, to, date } = req.query;

  try {
    const response = await amadeus.shopping.flightOffersSearch.get({
      originLocationCode: from,
      destinationLocationCode: to,
      departureDate: date,
      adults: "1",
      nonStop: true,
      currencyCode: "VND",
      max: 5,
    });

    const results = [];

    for (const offer of response.data) {
      const segment = offer.itineraries?.[0]?.segments?.[0];
      if (
        !segment ||
        !segment.departure ||
        !segment.arrival ||
        !segment.number ||
        !segment.carrierCode
      ) {
        console.warn(" Bỏ qua offer vì thiếu dữ liệu:", segment);
        continue;
      }

      const departureDateTime = segment.departure.at;
      const departureDate = new Date(departureDateTime.split("T")[0]);
      const departureTime = departureDateTime.split("T")[1].slice(0, 5);

      const hashedFlightNumber = `${segment.number}-${
        departureDate.toISOString().split("T")[0]
      }`;

      const flightData = {
        iata_from: segment.departure.iataCode,
        iata_to: segment.arrival.iataCode,
        departure_date: departureDate,
        departure_time: departureTime,
        price: parseFloat(offer.price.total),
        seat: { economy: 50, premium: 10 },
        flight_number: hashedFlightNumber,
        title: `${segment.carrierCode} ${segment.number}`,
        thumbnail: "",
      };

      const exists = await Flight.findOne({
        flight_number: flightData.flight_number,
      });

      if (!exists) {
        try {
          const saved = await Flight.create(flightData);
          results.push(saved);
        } catch (err) {
          if (err.code === 11000) {
            console.warn(
              `Flight already exists (duplicate flight_number): ${flightData.flight_number}`
            );
            continue;
          } else {
            throw err;
          }
        }
      } else {
        console.log(`Flight already exists in DB: ${flightData.flight_number}`);
      }
    }
    res.json({
      message: "Flights fetched and saved (if not exist)",
      saved: results.length,
      results,
    });
  } catch (error) {
    console.error(
      "Amadeus search/store error:",
      error.response?.data || error.message || error
    );
    res.status(500).json({ message: "Failed to fetch/store flights" });
  }
};

const calculateTotalPrice = (basePrice, passengers) => {
  const { adults, children, infants } = passengers;
  return (
    basePrice * adults + basePrice * 0.75 * children + basePrice * 0.1 * infants
  );
};

exports.fullSearchHandler = async (req, res) => {
  const { from, to, departureDate, returnDate, passengers, seat_class } =
    req.fullsearch;

  try {
    const seatKey = `seat.${seat_class.toLowerCase()}`;

    const outbound = await Flight.find({
      iata_from: from,
      iata_to: to,
      departure_date: departureDate,
      [seatKey]: { $gt: 0 },
      deleted: false,
    }).sort({ departure_time: 1 });

    const outboundWithPrice = outbound.map((f) => ({
      ...f._doc,
      total_price: calculateTotalPrice(f.price, passengers),
    }));

    let inboundWithPrice = [];
    if (returnDate) {
      const inbound = await Flight.find({
        iata_from: to,
        iata_to: from,
        departure_date: returnDate,
        [seatKey]: { $gt: 0 },
        deleted: false,
      }).sort({ departure_time: 1 });

      inboundWithPrice = inbound.map((f) => ({
        ...f._doc,
        total_price: calculateTotalPrice(f.price, passengers),
      }));
    }

    res.status(200).json({
      message: "Full search results",
      outbound: outboundWithPrice,
      inbound: inboundWithPrice,
    });
  } catch (error) {
    console.error("[GET /flights/fullsearch] Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
